/*
 *  Project/Assignment Name: Individual Assignment Palindrome
 *  Author: Nate Ramey
 *  Date: 05/01/2019
 *  Description: This program determines if a word or numbers is a palindrome via singly and doubly linked lists.
 */

#include <string>
#include <iostream>
#include <cstdlib>
#include <list>
#include <forward_list>

using namespace std;

// Singly Linked List
struct node
{
	char data;
	node* next;
}*head;

// Doubly Linked List
struct doublyNode
{
	char data;
	doublyNode* next;
	doublyNode* prev;
} *doublyHead, *doublyTail;


// Singly Node functions
void createSinglyNode(string input);
void printSinglyNode(node* head);
bool checkPalindrome(node* head);

// Doubly Node functions
void createDoublyNode(string input);
void printDoublyNode(doublyNode* doublyHead);
bool checkPalindrome(doublyNode* head, doublyNode* tail);

// Singly function to determine if Palindrome
node* findMiddle(node* head, bool &odd);
void reverse(node* &head);
bool compare(node* a, node* b);


int main()
{
	// Capture input for test string
	string input;

	// User inputs word/numbers to see if palindrome
	cout << "Singly linked list Palindrome test\n";
	cout << "Enter word/numbers to test if Palindrome\n";
	cin >> input;


	//Singly Linked List Function 
	createSinglyNode(input);
	printSinglyNode(head);
	if (checkPalindrome(head))
		cout << " is A Palindrome" << endl;
	else
		cout << " is NOT A Palindrome" << endl;
	cout << endl;
	std::cin.get();


	// Requesting input from user for doubly linked list.
	cout << "Doubly linked list Palindrome test\n";
	cout << "Enter word/numbers to test if Palindrome\n";
	cin >> input;

	// Function to create Doubly Linked List based on input
	createDoublyNode(input);
	printDoublyNode(doublyHead);
	if (checkPalindrome(doublyHead, doublyTail))
		cout << " is A Palindrome" << endl;
	else
		cout << " is NOT A Palindrome" << endl;
	cout << endl;
	std::cin.get();
}

// Singly Node Functions
void createSinglyNode(string input)
{
	node* curr;
	node* temp;
	int length = input.length();

	head = new node;
	head -> data = input[0];
	head -> next = NULL;
	temp = head;
	curr = head;

	for (int i = 1; i < length; i++)
	{
		curr = new node;
		curr -> data = input[i];
		temp -> next = curr;
		temp = temp -> next;
	}
	temp -> next = NULL;
}

// Prints the Singly Linked List created
void printSinglyNode(node* head)
{
	node* curr = head;
	while (curr -> next != nullptr)
	{
		cout << curr -> data;
		curr = curr -> next;
	}
	cout << curr -> data;
	
}

// Checks to see if List is Palindrome
bool checkPalindrome(node * head)
{
	// Base pointer
	if (head == nullptr)
		return true;

	// Determines to see if nodes even/odd number. Voids if odd.
	bool odd = false;

	// Second half of linked list
	node* mid = findMiddle(head, odd);

	// Odd Number of nodes will advance
	if (odd)
		mid = mid -> next;

	// Second half is reveresed
	reverse(mid);

	// First and Second halfs are compared
	return compare(head, mid);
	return false;
}

//Singly function to find middle of the string
node* findMiddle(node* head, bool &odd)
{
	node* prev = nullptr;
	node *slow = head, *fast = head;

	// Middle Pointer location
	while (fast && fast -> next)
	{
		prev = slow;
		slow = slow -> next;
		fast = fast -> next -> next;
	}

	// Odd nodes is still located 
	if (fast)
		odd = true;

	// Previous Node is null
	prev -> next = nullptr;

	// Finds mid node
	return slow;
}

// Function reverses the nods of a linked list
void reverse(node* &head)
{
	node* result = nullptr;
	node* current = head;

	while (current != nullptr)
	{
		node* next = current -> next;
		current -> next = result;
		result = current;
		current = next;
	}
	head = result;
}

// Singly function to compare the two "halfs"
bool compare(node* a, node* b)
{
	// Determines if list is empty or not
	if (a == nullptr && b == nullptr)
		return true;

	return a && b && (a -> data == b -> data) && compare( a-> next, b -> next);
}


// Doubly Function Nodes.
void createDoublyNode(string input)
{
	doublyNode* n;

	int length = input.length();

	n = new doublyNode;
	n -> data = input[0];
	n -> next = NULL;
	n -> prev = NULL;
	doublyHead = n;
	doublyTail = n;
	if (length > 1)
	{
		for (int i = 1; i < length; i++)
		{
			n = new doublyNode;
			n -> data = input[i];
			n -> prev = doublyTail;
			doublyTail -> next = n;
			doublyTail = n;
		}
		doublyTail -> next = NULL;
	}
}

// Doubly Functions determine palindrome.
bool checkPalindrome(doublyNode* head, doublyNode* tail)
{
	bool isPalindrome = true;
	doublyNode* ftemp = head;
	doublyNode* ltemp = tail;
	do
	{
		if (ftemp -> data != ltemp -> data)
			isPalindrome = false;
		ftemp = ftemp -> next;
		ltemp = ltemp -> prev;
	} while (ftemp != ltemp && isPalindrome);

	return isPalindrome;
}

// Prints the Doubly Linked List
void printDoublyNode(doublyNode* doublyHead)
{
	doublyNode* curr = doublyHead;
	while (curr != NULL)
	{
		cout << curr -> data;
		curr = curr -> next;
	}
	std::cin.get();
}