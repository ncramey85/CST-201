/*
 *  Project/Assignment Name: Week 4 Maze project.
 *  Author: Nate Ramey
 *  Date: 05/19/2019
 *  Description: This program navigates through a maze utilizing a queue function.
 *  I am still having issues with displaying the maze onto the console screen. 
 */
#include <iostream>
#include <fstream>
#include <array>
#include <vector>
#include <algorithm>
#include <functional>
#include <string>
#include <iterator>
#include <queue>

using namespace std;

//Makes Grid / Array for maze
#define K 11
#define J 10

//Coordinates X and Y 
struct Point
{
	int x;
	int y;
};

//Starts the queue 
struct qNode
{
	Point point;
	int dist;
};

//Boolean search for walls/openings
bool isValid(int r, int c)
{
	return (r >= 0) && (r < K) &&
		(c >= 0) && (c < J);
}

//
int rNum[] = { -1, 0, 0, 1 };
int cNum[] = { 0, -1, 1, 0 };

//Breadth First Search to Find the Shortest path
// This was the only way I could get this to work was using a BFS function.
int BFS(int maze[][J], Point source, Point dest)
{
	if (!maze[source.x][source.y] || !maze[dest.x][dest.y])
		return INT_MAX;

	bool visited[K][J];
	memset(visited, false, sizeof visited);

	visited[source.x][source.y] = true;

	queue<qNode> q;

	//Pops the queue stack starting from the SOURCE to the Finish 
	qNode s = { source, 0 };
	q.push(s);

	while (!q.empty())
	{
		qNode curr = q.front();
		Point pt = curr.point;

		if (pt.x == dest.x && pt.y == dest.y)
			return curr.dist;

		q.pop();

		for (int i = 0; i < 4; i++)
		{
			int r = pt.x + rNum[i];
			int c = pt.y + cNum[i];

			if (isValid(r, c) && maze[r][c] &&
				!visited[r][c])
			{
				visited[r][c] = true;
				qNode Adjcell = { {r, c},
									  curr.dist + 1 };
				q.push(Adjcell);
			}
		}
	}

	return INT_MAX;
}

// One and Zeros make paths/walls for the maze
int main()
{
	int mat[K][J] =
	{
			{1, 1, 1, 1, 0, 1, 1, 1, 1, 1},
			{1, 0, 0, 0, 1, 1, 0, 0, 0, 1},
			{1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
			{1, 1, 1, 0, 1, 0, 1, 0, 1, 0},
			{1, 0, 1, 0, 1, 0, 1, 1, 1, 1},
			{1, 1, 1, 1, 1, 0, 1, 1, 0, 1},
			{0, 1, 1, 1, 0, 1, 1, 0, 0, 1},
			{0, 0, 0, 0, 1, 1, 1, 1, 1, 0},
			{1, 1, 0, 1, 1, 1, 0, 1, 0, 1},
			{0, 1, 1, 1, 0, 1, 0, 1, 1, 1},
			{1, 1, 1, 1, 0, 1, 1, 1, 0, 1}
	};


	//Displays the maze 
	Point source = { 0, 0 };
	Point dest = { 10, 3 };

	int dist = BFS(mat, source, dest);

	if (dist != INT_MAX)
		cout << "Shortest Path through the Maze is " << dist;
	else
		cout << "Task Failed Successfully!";

	std::cin.get();
}