/*
 *  Project/Assignment Name: Week 3 Maze project.
 *  Author: Nate Ramey
 *  Date: 05/12/2019
 *  Description: This program navigates through a maze utilizing a series of stacks as navigation.
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stdio.h>
#include <string.h>
#include <iomanip>
#include <vector>
#include <stack>

using namespace std;

class Grid {
public:
	Grid(int rr, int cc) : m_r(rr), m_c(cc) {}
	int r() const { return m_r; }
	int c() const { return m_c; }
private:
	int m_r;
	int m_c;
};
int minimum(int a[], int size) {
	int small = a[0];
	for (int i = 0; i < size; i++)
		if (a[i] < small)
			small = a[i];
	return small;
}




class Control; //Class for directions moving through the maze

enum Direction
{
	Left,
	Right,
	Up,
	Down
};

vector<vector<int>> Control(vector<vector<int>> grid)
{
	stack<int> Cursor; //Locating the starting position for the cursor 
	stack<Direction> pop; // Tracks which direction to move after stack is "popped" 
	int x; // Location on the Grid 
	int y; // Location on the grid
	for (int i = 0; i < grid.size(); i++)
	{
		for (int j = 0; j < grid[i].size(); j++)
		{
			if (grid[i][j] == 3)
			{
				Cursor.push(grid[i][j]);
				x = i;
				y = j;
			}
		}
	}

	// Initiate the maze
	bool finished = false;
	while (!finished)
	{
		// Directions for up, down, right, left. Activly looking for a value of 0 (zero)  
		if (x - 1 != -1 && grid[x - 1][y] == 0)        //Grid Coordinates to move UP
		{
			grid[x - 1][y] = 5;
			Cursor.push(grid[x - 1][y]);
			x -= 1;
			pop.push(Down);
		}
		else if (y + 1 != grid[x].size() && grid[x][y + 1] == 0)        //Grid Coordinates to move Right
		{
			grid[x][y + 1] = 5;
			Cursor.push(grid[x][y + 1]);
			y += 1;
			pop.push(Left);
		}
		else if (x + 1 != grid.size() && grid[x + 1][y] == 0)        //Grid Coordinates to move Down
		{
			grid[x + 1][y] = 5;
			Cursor.push(grid[x + 1][y]);
			x += 1;
			pop.push(Up);
		}
		else if (y - 1 != -1 && grid[x][y - 1] == 0)        // Grid Coordinates to move Left
		{
			grid[x][y - 1] = 5;
			Cursor.push(grid[x][y - 1]);
			y -= 1;
			pop.push(Right);
		}
		else // Pop off top of the stack if there isn't a a value i.e.(0)
		{
			switch (pop.top())
			{
			case Up: // Stack to Move Up
				Cursor.pop();
				pop.pop();
				grid[x][y] = 4;
				x -= 1;
				break;

			case Down: //Stack to move down
				Cursor.pop();
				pop.pop();
				grid[x][y] = 4;
				x += 1;
				break;

			case Right: // Stack to Move Right
				Cursor.pop();
				pop.pop();
				grid[x][y] = 4;
				y += 1;
				break;


			case Left: //Stack to move left
				Cursor.pop();
				pop.pop();
				grid[x][y] = 4;
				y -= 1;
				break;
			}
		}
		if (x - 1 != -1 && grid[x - 1][y] == 2)        //X&Y Coordinates to move UP
			finished = true;
		else if (y + 1 != grid[x].size() && grid[x][y + 1] == 2)        //X&Y Coordinates to move Right
			finished = true;
		else if (x + 1 != grid.size() && grid[x + 1][y] == 2)        //X&Y Coordinates to move Down
			finished = true;
		else if (y - 1 != -1 && grid[x][y - 1] == 2)        //X&Y Coordinates to move Left
			finished = true;
	}
	return grid;
}

// Grid for the Maze
int main() {
	string txt[12];
	string line;

	int i = 0;
	ifstream file("maze\src\input_file.txt");
	if (file.is_open()) {
		while (!file.eof()) {
			getline(file, line);
			txt[i] = line;
			i++;
		}
	}
	file.close();

	ofstream myfile;
	myfile.open("output_file.txt");

	int height = 11;
	int width = 10;

	string open = ".";
	string start = "S";
	string free = "F";
	string wall = "X";

	string blockArray[11][10] = {
			{"S",".",".",".","X",".",".",".",".","."},
			{".","X","X","X",".",".","X","X","X","."},
			{".","X",".","X",".","X",".","X",".","."},
			{".",".",".","X",".","X",".","X",".","X"},
			{".","X",".","X",".","X",".",".",".","."},
			{".",".",".",".",".","X",".",".","X","."},
			{"X",".",".",".","X",".",".","X","X","."},
			{"X","X","X","X",".","X",".",".",".","X"},
			{".",".","X",".",".",".","X",".","X","."},
			{"X",".",".",".","X",".","X",".",".","."},
			{".",".",".","F","X",".",".",".","X","."},
	};


	for (int i = 0; i < height; i++) {

		// Creates the values
		if (i == 0) {
			myfile << "   ";
			for (int j = 0; j < width; j++) {
				myfile << " " << j << " ";
			}
			myfile << endl;
			myfile << "   ";
			for (int j = 0; j < width; j++) {
				myfile << "_" << "_" << "_";
			}
			myfile << endl;
		}

		// 3x3 block to read if its a wall/clearing/start/finish
		for (int h = 0; h < 3; h++) {

			if (h == 1 && i < 10) {
				myfile << i << " |";
			}
			else if (h == 1 && i >= 10) {
				myfile << i << "|";
			}
			else {
				myfile << "  |";
			}

			for (int j = 0; j < width; j++) {
				for (int k = 0; k < 3; k++) {
					if (k != 1) {
						if (blockArray[i][j] == start) { //Array for "Start" 
							myfile << ".";
						}
						else if (blockArray[i][j] == free) { // Array for "free" movement 
							myfile << ".";
						}
						else if (blockArray[i][j] == wall) { // Array for "Wall"
							myfile << "X";
						}
						else if (blockArray[i][j] == open) { //Array for "Open" 
							myfile << ".";
						}
					}
					else {
						if (blockArray[i][j] == start) {
							if (h == 1) {
								myfile << "S"; //Navigation instructs where to start referencing the input file
							}
							else {
								myfile << ".";
							}
						}
						else if (blockArray[i][j] == free) { //Navigation instructs what is "free" all the way to the "F" which is the finish. 
							if (h == 1) {
								myfile << "F";
							}
							else {
								myfile << ".";
							}
						}
						else if (blockArray[i][j] == wall) { // Navigation instructs what is a wall 
							myfile << "X";
						}
						else if (blockArray[i][j] == open) { // Navigation instructs what is open
							myfile << ".";
						}
					}
				}

			}
			myfile << endl;
		}

	}

	// write maze to file
	//Unable to get the maze to display in the console window. However it is able to write in the "output_file" 
	myfile.close();
	std::cin.get();
}
