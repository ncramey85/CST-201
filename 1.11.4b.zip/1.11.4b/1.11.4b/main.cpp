#include <iostream>
#include <sstream>

using namespace std;

int number[] = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 35, 89 };   // Numbers Array
int s = sizeof(number) / sizeof(number[0]);    // Size of array

string origArray = "";      
string newArray = "";   

int *p;

string originalArray() {
	p = number;
	for (int i = 0; i < s; i++) {
		ostringstream ss;       
		ss << *p;
		origArray = origArray + ss.str() + " "; // Outputs it a string
		p++;
	}
	return origArray;
}

string removeOdd() {
	p = number;
	for (int i = 0; i < s; i++) {
		if (*p % 2 ) {
			ostringstream ss;    
			ss << *p;
			newArray = newArray + ss.str() + " "; // Makes it a string

		}
		p++;    // Increment pointer
	}
	return newArray;
}

int main()
{
	cout << "Original Numbers Array" << originalArray() << endl;
	cout << "Odd numbers removed from array " << removeOdd() << endl;
	std::cin.get();
}