#include <stdio.h>
#include <iostream>

int GCD(int, int);

int main()
{
	int n, m, result;

	printf("Enter two numbers to find their GCD ");

	scanf_s("%d%d", &n, &m);

	result = GCD(n, m);

	printf("GCD of %d and %d is %d.\n", n, m, result);

	std::cin.get();

}

int GCD(int n, int m)
{
	if (m <= n && n%m <= 0)
	{
		return m;
	}
	else if (n < m)
	{
		return GCD(m, n);
	}
	else
	{
		return GCD(m, n%m);
	}

	std::cin.get();
}