/*
 *  Project/Assignment Name: Week 5 Maze project.
 *  Author: Nate Ramey
 *  Date: 05/23/2019
 *  Description: This program navigates through a maze utilizing a heap function
 *  I cannot get the last cout << i.getMin() << " "; to work for the life of me.
 */


#include <iostream>
#include <fstream>
#include <array>
#include <vector>
#include <algorithm>
#include <functional>
#include <string>
#include <iterator>
#include <climits>

using namespace std;
void change(int *x, int *y);

class Heap
{
	int *heap;
	int capacity;
	int heapSize;

public:
	Heap(int capacity);
	void Heaping(int);
	int parent(int i) {
		return (i - 1) / 2;
	}
	int left(int i) {
		return (2 * i + 1);
	}
	int right(int i) {
		return (2 * i + 2);
	}
	int extract();
	void Keydecrease(int i, int new_val);
	int getMin() {
		return heap[0];
	}
	void deleteKey(int i);
	void insertKey(int k);
};

Heap::Heap(int cap)
{
	heapSize = 0;
	capacity = cap;
	heap = new int[cap];
}

void Heap::insertKey(int k)
{
	if (heapSize == capacity)
	{
		cout << "\n Overflow: Inserting Ket isn't possible \n";
		return;
	}

	heapSize++;
	int i = heapSize - 1;
	heap[i] = k;

	while (i != 0 && heap[parent(i)] > heap[i])
	{
		change(&heap[i], &heap[parent(i)]);
		i = parent(i);
	}
}

void Heap::Keydecrease(int i, int value)
{
	heap[i] = value;
	while (i != 0 && heap[parent(i)] > heap[i])
	{
		change(&heap[i], &heap[parent(i)]);
		i = parent(i);
	}
}

int Heap::extract()
{
	if (heapSize <= 0)
		return INT_MAX;
	if (heapSize == 1)
	{
		heapSize--;
		return heap[0];
	}

	int root = heap[0];
	heap[0] = heap[heapSize - 1];
	heapSize--;
	Heaping(0);

	return root;
}

void Heap::deleteKey(int i)
{
	Keydecrease(i, INT_MIN);
	extract();
}

void Heap::Heaping(int i)
{
	int l = left(i);
	int r = right(i);
	int small = i;
	if (l < heapSize && heap[l] < heap[i])
		small = l;
	if (r < heapSize && heap[r] < heap[small])
		small = r;
	if (small != i)
	{
		change(&heap[i], &heap[small]);
		Heaping(small);
	}
}

void change(int *x, int *y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}

int main()
{
	int mat[11][10] =
	{
			{1, 1, 1, 1, 0, 1, 1, 1, 1, 1},
			{1, 0, 0, 0, 1, 1, 0, 0, 0, 1},
			{1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
			{1, 1, 1, 0, 1, 0, 1, 0, 1, 0},
			{1, 0, 1, 0, 1, 0, 1, 1, 1, 1},
			{1, 1, 1, 1, 1, 0, 1, 1, 0, 1},
			{0, 1, 1, 1, 0, 1, 1, 0, 0, 1},
			{0, 0, 0, 0, 1, 1, 1, 1, 1, 0},
			{1, 1, 0, 1, 1, 1, 0, 1, 0, 1},
			{0, 1, 1, 1, 0, 1, 0, 1, 1, 1},
			{1, 1, 1, 1, 0, 1, 1, 1, 0, 1}
	};

	cout << i.extractMin() << " ";
	cout << i.getMin() << " ";
	return 0;
}
