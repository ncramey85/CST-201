#include <iostream>

using namespace std;

int numbers[] = { 10, 15, 9, 3, 2, 24 };   // Numbers for the array
int s = sizeof(numbers) / sizeof(numbers[0]); // Array size
int total = 0;
int *p;

int allNumbers() {
	p = numbers;
	for (int i = 0; i < s; i++) {
		total = total + *p;     // Add pointer for the total
		p++;                    // Increment pointer
	}
	return total;
}

int main()
{
	cout << "The sum of all numbers in the array is " << allNumbers() << endl;
	std::cin.get();
}

