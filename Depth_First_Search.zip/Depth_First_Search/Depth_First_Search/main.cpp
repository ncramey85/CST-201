//Depth First Search 
//Maze 6 Project 

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stdio.h>
#include <string.h>
#include <stack>
#include <iomanip>
#include <list>
#include <limits.h>

using namespace std;

class Coordinates {
public:
	Coordinates(int rr, int cc) : m_r(rr), m_c(cc) {}
	int r() const { return m_r; }
	int c() const { return m_c; }
private:
	int m_r;
	int m_c;
};
int minimum(int a[], int size) {
	int small = a[0];
	for (int i = 0; i < size; i++)
		if (a[i] < small)
			small = a[i];
	return small;
}
//Determines distance for DFS 
void distanceDetermination(const char maze[][10], int sr, int sc, int dist[][10]) {
	stack <Coordinates> coordStack;
	coordStack.push(Coordinates(sr, sc));
	for (int i = 0; i < 10; i++)
		for (int j = 0; j < 10; j++)
		{
			dist[i][j] = 99;
		}
	dist[sr][sc] = 0;
	int distarr[11];
	int min;
	int currval;
	while (!coordStack.empty()) {

		Coordinates inuse = coordStack.top();
		coordStack.pop();
		const int row = inuse.r();
		const int col = inuse.c();

		//Navigation through the rows columns
		cout << "row" << row << "col" << col << endl;
		distarr[0] = dist[row - 1][col];    //      Up
		distarr[1] = dist[row + 1][col];    //      Down
		distarr[2] = dist[row][col + 1];    //      Right
		distarr[3] = dist[row][col - 1];    //      Left
		min = minimum(distarr, 11);

		if (dist[row][col] > min + 1)
			dist[row][col] = min + 1;
		currval = dist[row][col];

		if ((maze[row - 1][col] == '.') && (dist[row - 1][col] > (currval + 1))) {
			dist[row - 1][col] = currval + 1;
			coordStack.push(Coordinates(row + 1, col));
		}
		if (maze[row + 1][col] == '.' && (dist[row + 1][col] > (currval + 1))) {
			coordStack.push(Coordinates(row + 1, col));
		}
		if (maze[row][col + 1] == '.' && (dist[row][col + 1] > (currval + 1))) {
			dist[row][col + 1] = currval + 1;
			coordStack.push(Coordinates(row, col + 1));
		}
		if (maze[row][col - 1] == '.' && (dist[row][col - 1] > (currval + 1))) {
			dist[row][col - 1] = dist[row][col] + 1;
			coordStack.push(Coordinates(row, col - 1));
		}
	}
}

//Vertices for the layout of the graph 
class MazeGraph
{
	int V;

	list <int> *adj;

	void DFSUtil(int v, bool visited[]);

public:
	MazeGraph(int V);

	void edge(int v, int w);

	void DFS(int v);
};

MazeGraph :: MazeGraph(int V)
{
	this -> V = V;
	adj = new list <int> [V];
}

void MazeGraph :: edge(int v, int w)
{
	adj[v].push_back(w);
}

void MazeGraph :: DFSUtil(int v, bool visited[])
{

	visited[v] = true;
	cout << v << " ";

	list<int>::iterator i;
	for (i = adj[v].begin(); i != adj[v].end(); ++i)
		if (!visited[*i])
			DFSUtil(*i, visited);
}

void MazeGraph :: DFS(int v)
{

	bool *visited = new bool[V];
	for (int i = 0; i < V; i++)
		visited[i] = false;

	DFSUtil(v, visited);
}

int main() {
	string txt[12];
	string line;

	int i = 0;
	ifstream file("Depth_First_Search/Source Files/input_file.txt");
	if (file.is_open()) {
		while (!file.eof()) {
			getline(file, line);
			txt[i] = line;
			i++;
		}
	}
	file.close();

	//Edges referencing the input_file 
	MazeGraph g(11);
	g.edge(0, 0);
	g.edge(3, 10);
	g.edge(0, 6);
	g.edge(0, 7);
	g.edge(0, 9);
	g.edge(1, 1);
	g.edge(1, 2);
	g.edge(1, 4);
	g.edge(1, 7);
	g.edge(2, 1);
	g.edge(2, 7);
	g.edge(2, 8);
	g.edge(2, 10);
	g.edge(3, 1);
	g.edge(3, 2);
	g.edge(3, 3);
	g.edge(3, 4);
	g.edge(3, 7);
	g.edge(4, 0);
	g.edge(4, 6);
	g.edge(4, 9);
	g.edge(4, 10);
	g.edge(5, 2);
	g.edge(5, 3);
	g.edge(5, 4);
	g.edge(5, 5);
	g.edge(5, 7);
	g.edge(6, 1);
	g.edge(6, 8);
	g.edge(6, 9);
	g.edge(7, 1);
	g.edge(7, 2);
	g.edge(7, 3);
	g.edge(7, 6);
	g.edge(8, 1);
	g.edge(8, 5);
	g.edge(8, 6);
	g.edge(8, 8);
	g.edge(8, 10);
	g.edge(9, 3);
	g.edge(9, 7);

	cout << "Depth First Traversal is:"
		" \n";
	g.DFS(2);

	ofstream myfile;
	myfile.open("maze_project.txt");

	//Size of array 11 X 10
	int height = 11;
	int width = 10;

	//declaring start,wall,free,open
	string start = "S";
	string open = "1";
	string wall = "0";
	string finish = "F";

	//Block Array Construction
	string blockArray[11][10] = {
			{"S","1","1","1","0","1","1","1","1","1"},
			{"1","0","0","0","1","1","0","0","0","1"},
			{"1","0","1","0","1","0","1","0","1","1"},
			{"1","1","1","0","1","0","1","0","1","0"},
			{"1","0","1","0","1","0","1","1","1","1"},
			{"1","1","1","1","1","0","1","1","0","1"},
			{"0","1","1","1","0","1","1","0","0","1"},
			{"0","0","0","0","1","0","1","1","1","0"},
			{"1","1","0","1","1","1","0","1","0","1"},
			{"0","1","1","1","0","1","0","1","1","1"},
			{"1","1","1","F","0","1","1","1","0","1"},
	};

	for (int i = 0; i < height; i++) {

		// runs to create the values for the DFS
		if (i == 0) {
			myfile << "   ";
			for (int j = 0; j < width; j++) {
				myfile << " " << j << " ";
			}
			myfile << endl;
			myfile << "   ";
			for (int j = 0; j < width; j++) {
				myfile << "_" << "_" << "_";
			}
			myfile << endl;
		}

		for (int h = 0; h < 3; h++) {

			if (h == 1 && i < 10) {
				myfile << i << "|";
			}
			else if (h == 1 && i >= 10) {
				myfile << i << "|";
			}
			else {
				myfile << "|";
			}
			//Start,finish, open , wall referencing block array
			for (int j = 0; j < width; j++) {
				for (int k = 0; k < 3; k++) {
					if (k != 1) {
						if (blockArray[i][j] == start) {
							myfile << "S";
						}
						else if (blockArray[i][j] == finish) {
							myfile << "1";
						}
						else if (blockArray[i][j] == wall) {
							myfile << "0";
						}
						else if (blockArray[i][j] == open) {
							myfile << "1";
						}
					}
					else {
						if (blockArray[i][j] == start) {
							if (h == 1) {
								myfile << "S";
							}
							else {
								myfile << "1";
							}
						}
						else if (blockArray[i][j] == finish) {
							if (h == 1) {
								myfile << "F";
							}
							else {
								myfile << "1";
							}
						}
						else if (blockArray[i][j] == wall) {
							myfile << "0";
						}
						else if (blockArray[i][j] == open) {
							myfile << "1";
						}
					}
				}

			}
			myfile << endl;
		}
	}
	myfile.close();

std:cin.get();
}